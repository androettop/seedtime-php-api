<?php
return array(
    "host"      =>"host_mysql",
    "user"      =>"usuario_db",
    "pass"      =>"pass_db",
    "database"  =>"nombre_db",
    );
?>
