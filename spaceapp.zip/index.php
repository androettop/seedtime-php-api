<?php
require_once 'classes/mysql.php';
require_once 'classes/config.php';
$cfg = new Config();
require_once 'config/rutas.php';
?>
